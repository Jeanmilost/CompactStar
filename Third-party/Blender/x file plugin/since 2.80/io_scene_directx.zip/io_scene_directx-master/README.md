# io_scene_directx
A DirectX Model Exporter for Blender 2.8+

To use this project locate your blender folder on your hard disk and save this project into that folder. Restart / Open Blender and then the option to export as a *.x model will be available with the other export models.
